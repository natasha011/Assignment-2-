Vue.component('dropdown', {
	template: `
		<div>
			<button @click='toggleShow' class='anchor'>Gender </button>
			<div v-if='showMenu' class='menu'>
				<div class='menu-item' v-for='item in this.items' @click='itemClicked(item)'>{{item}}</div>
			</div>
		</div>
	`,
	data: function() {
		return {
			showMenu: false
		}
	},
	props: {
		onClick: 'function',
		items: {
			type: 'Object',
	
		}
	},
	methods: {
		toggleShow: function() {
			this.showMenu = !this.showMenu;
		},
		itemClicked: function(item) {
			this.toggleShow();
			this.onClick(item);
		}
	}
})

const GenDrp = new Vue({
	el: '#GenDrp',
	data: {
		
		Genders: [
			'Male',
			'Female',
			'Other',
	
		]
	},
	methods: {
		changeGender: function(gender) {
			this.activeGender = gender;
		}
	}
})

Vue.component('child-component', {
  template: '#child-component',
  data() {
      return {
        childTitle: 'title from child component',
        childSubtitle: 'subtitle from child component'
      }
  },
  props:{
    subtitle: {
      type: String,
      required: true
    }
  }
})

new Vue ({
  el: '#app',
  data() {
      return {
        title: 'Hello Vue',
        subtitle: 'how to use slots'
    }
  }
})