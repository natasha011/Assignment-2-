const UserName = {
  props: {
    firstName: String,
    Age: [String, Number]
  },
  template: `
    <input 
      type="text"
      :value="firstName"
      @input="$emit('update:firstName', $event.target.value)">

    <input
      type="text"
      :value="Age"
      @input="$emit('update:Age', $event.target.value)">
  `
};

const HelloVueApp = {
  components: {
    UserName,
  },
  data() {
    return {
      firstName: 'John',
      Age: '9',
    };
  },
};

Vue.createApp(HelloVueApp).mount('#v-model-example')

